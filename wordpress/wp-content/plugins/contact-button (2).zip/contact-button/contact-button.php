<?php
/**
 * Plugin Name: Nút Liên Hệ Tư Vấn
 * Plugin URI: https://yourwebsite.com
 * Description: Plugin tạo nút liên hệ với nhiều tư vấn viên (Zalo và số điện thoại), có thể thiết lập khác nhau cho mỗi trang và sản phẩm WooCommerce
 * Version: 2.2
 * Author: Vũ Đình Thiện
 * License: GPL2
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ContactButtonPlugin {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'display_contact_button'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_meta_boxes'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('wp_ajax_save_contact_list', array($this, 'save_contact_list'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        
        // Hook để check WooCommerce
        add_action('plugins_loaded', array($this, 'check_woocommerce'));
    }
    
    public function init() {
        // Plugin initialization
    }
    
    public function check_woocommerce() {
        // Check if WooCommerce is active
        if (class_exists('WooCommerce')) {
            // Add WooCommerce specific hooks
            add_action('woocommerce_product_options_general_product_data', array($this, 'add_product_contact_fields'));
            add_action('woocommerce_process_product_meta', array($this, 'save_product_contact_fields'));
            
            // Add tab in product data
            add_filter('woocommerce_product_data_tabs', array($this, 'add_product_contact_tab'));
            add_action('woocommerce_product_data_panels', array($this, 'add_product_contact_panel'));
        }
    }
    
    public function enqueue_scripts() {
        // Only enqueue if files exist
        if (file_exists(plugin_dir_path(__FILE__) . 'contact-button.js')) {
            wp_enqueue_script('contact-button-script', plugin_dir_url(__FILE__) . 'contact-button.js', array('jquery'), '2.2', true);
        }
    }
    
    public function admin_scripts() {
        wp_enqueue_script('jquery');
        if (file_exists(plugin_dir_path(__FILE__) . 'admin.js')) {
            wp_enqueue_script('contact-admin-js', plugin_dir_url(__FILE__) . 'admin.js', array('jquery'), '2.2', true);
            wp_localize_script('contact-admin-js', 'contact_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('contact_nonce')
            ));
        }
    }
    
    // Add WooCommerce product contact tab
    public function add_product_contact_tab($tabs) {
        $tabs['contact_consultants'] = array(
            'label'    => 'Tư Vấn Viên',
            'target'   => 'contact_consultants_data',
            'class'    => array('show_if_simple', 'show_if_variable'),
            'priority' => 80,
        );
        return $tabs;
    }
    
    // Add WooCommerce product contact panel
    public function add_product_contact_panel() {
        global $post;
        
        if (!$post) {
            return;
        }
        
        $product_contacts = get_post_meta($post->ID, '_product_contact_consultants', true);
        if (!is_array($product_contacts)) $product_contacts = array();
        $disable_product = get_post_meta($post->ID, '_disable_contact_for_product', true);
        
        ?>
        <div id="contact_consultants_data" class="panel woocommerce_options_panel">
            <div class="options_group">
                <p class="form-field">
                    <label>
                        <input type="checkbox" name="_disable_contact_for_product" value="1" <?php checked(1, $disable_product, true); ?> />
                        Tắt nút liên hệ cho sản phẩm này
                    </label>
                </p>
                
                <h3>Tư Vấn Viên Cho Sản Phẩm Này:</h3>
                <div id="product-contact-list" style="padding: 0 20px;">
                    <?php if (!empty($product_contacts)): ?>
                        <?php foreach ($product_contacts as $index => $contact): ?>
                        <div class="product-contact-item" data-index="<?php echo intval($index); ?>" style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; background: #f9f9f9; border-radius: 5px;">
                            <h4 style="margin-top: 0; color: #0073aa;">Tư vấn viên #<?php echo intval($index + 1); ?></h4>
                            <p>
                                <label><strong>Tên:</strong></label><br>
                                <input type="text" name="product_contacts[<?php echo intval($index); ?>][name]" 
                                       value="<?php echo esc_attr(isset($contact['name']) ? $contact['name'] : ''); ?>" style="width: 100%; margin-bottom: 10px;" />
                            </p>
                            <p>
                                <label><strong>Số điện thoại:</strong></label><br>
                                <input type="text" name="product_contacts[<?php echo intval($index); ?>][phone]" 
                                       value="<?php echo esc_attr(isset($contact['phone']) ? $contact['phone'] : ''); ?>" style="width: 100%; margin-bottom: 10px;" />
                            </p>
                            <p>
                                <label><strong>Zalo:</strong></label><br>
                                <input type="text" name="product_contacts[<?php echo intval($index); ?>][zalo]" 
                                       value="<?php echo esc_attr(isset($contact['zalo']) ? $contact['zalo'] : ''); ?>" style="width: 100%; margin-bottom: 10px;" />
                            </p>
                            <p>
                                <label><strong>Chuyên môn/Mô tả:</strong></label><br>
                                <textarea name="product_contacts[<?php echo intval($index); ?>][description]" 
                                         style="width: 100%; height: 60px;" placeholder="VD: Chuyên tư vấn sản phẩm công nghệ, kinh nghiệm 5 năm..."><?php echo esc_textarea(isset($contact['description']) ? $contact['description'] : ''); ?></textarea>
                            </p>
                            <button type="button" class="button remove-product-contact" style="background: #dc3232; color: white; border: none;">Xóa</button>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <p class="form-field" style="padding: 0 20px;">
                    <button type="button" id="add-product-contact" class="button button-secondary" style="background: #0073aa; color: white; border: none;">+ Thêm Tư Vấn Viên</button>
                </p>
                
                <p class="form-field" style="padding: 0 20px; font-style: italic; color: #666;">
                    <strong>Lưu ý:</strong> Nếu không thiết lập tư vấn viên riêng, sản phẩm sẽ sử dụng danh sách tư vấn viên mặc định từ cài đặt chung.
                </p>
            </div>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            var productContactIndex = <?php echo count($product_contacts); ?>;
            
            $('#add-product-contact').click(function() {
                var html = '<div class="product-contact-item" data-index="' + productContactIndex + '" style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; background: #f9f9f9; border-radius: 5px;">' +
                    '<h4 style="margin-top: 0; color: #0073aa;">Tư vấn viên #' + (productContactIndex + 1) + '</h4>' +
                    '<p><label><strong>Tên:</strong></label><br>' +
                    '<input type="text" name="product_contacts[' + productContactIndex + '][name]" value="" style="width: 100%; margin-bottom: 10px;" /></p>' +
                    '<p><label><strong>Số điện thoại:</strong></label><br>' +
                    '<input type="text" name="product_contacts[' + productContactIndex + '][phone]" value="" style="width: 100%; margin-bottom: 10px;" /></p>' +
                    '<p><label><strong>Zalo:</strong></label><br>' +
                    '<input type="text" name="product_contacts[' + productContactIndex + '][zalo]" value="" style="width: 100%; margin-bottom: 10px;" /></p>' +
                    '<p><label><strong>Chuyên môn/Mô tả:</strong></label><br>' +
                    '<textarea name="product_contacts[' + productContactIndex + '][description]" style="width: 100%; height: 60px;" placeholder="VD: Chuyên tư vấn sản phẩm công nghệ, kinh nghiệm 5 năm..."></textarea></p>' +
                    '<button type="button" class="button remove-product-contact" style="background: #dc3232; color: white; border: none;">Xóa</button>' +
                    '</div>';
                
                $('#product-contact-list').append(html);
                productContactIndex++;
            });
            
            $(document).on('click', '.remove-product-contact', function() {
                $(this).closest('.product-contact-item').remove();
            });
        });
        </script>
        <?php
    }
    
    // Save WooCommerce product contact fields
    public function save_product_contact_fields($post_id) {
        if (!$post_id) {
            return;
        }
        
        // Save disable setting
        $disable = isset($_POST['_disable_contact_for_product']) ? 1 : 0;
        update_post_meta($post_id, '_disable_contact_for_product', $disable);
        
        // Save product contacts
        $contacts = array();
        if (isset($_POST['product_contacts']) && is_array($_POST['product_contacts'])) {
            foreach ($_POST['product_contacts'] as $contact) {
                if (is_array($contact) && (!empty($contact['name']) || !empty($contact['phone']) || !empty($contact['zalo']))) {
                    $contacts[] = array(
                        'name' => sanitize_text_field(isset($contact['name']) ? $contact['name'] : ''),
                        'phone' => sanitize_text_field(isset($contact['phone']) ? $contact['phone'] : ''),
                        'zalo' => sanitize_text_field(isset($contact['zalo']) ? $contact['zalo'] : ''),
                        'description' => sanitize_textarea_field(isset($contact['description']) ? $contact['description'] : '')
                    );
                }
            }
        }
        update_post_meta($post_id, '_product_contact_consultants', $contacts);
    }
    
    // Add admin menu
    public function admin_menu() {
        add_options_page(
            'Cài Đặt Nút Liên Hệ',
            'Nút Liên Hệ',
            'manage_options',
            'contact-button-settings',
            array($this, 'admin_page')
        );
    }
    
    public function admin_init() {
        register_setting('contact_button_settings', 'contact_button_enable');
        register_setting('contact_button_settings', 'contact_button_default_contacts');
    }
    
    public function admin_page() {
        $contacts = get_option('contact_button_default_contacts', array());
        if (!is_array($contacts)) {
            $contacts = array();
        }
        ?>
        <div class="wrap">
            <h1>Cài Đặt Nút Liên Hệ</h1>
            <form method="post" action="options.php">
                <?php settings_fields('contact_button_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Bật/Tắt Plugin</th>
                        <td>
                            <input type="checkbox" name="contact_button_enable" value="1" <?php checked(1, get_option('contact_button_enable'), true); ?> />
                            <label>Bật hiển thị nút liên hệ</label>
                        </td>
                    </tr>
                </table>
                
                <h2>Danh Sách Tư Vấn Viên Mặc Định</h2>
                <p><em>Danh sách này sẽ được sử dụng cho tất cả trang/sản phẩm chưa có cài đặt riêng.</em></p>
                
                <div id="contact-list">
                    <?php if (!empty($contacts)): ?>
                        <?php foreach ($contacts as $index => $contact): ?>
                        <div class="contact-item" data-index="<?php echo intval($index); ?>">
                            <h4>Tư vấn viên #<?php echo intval($index + 1); ?></h4>
                            <table class="form-table">
                                <tr>
                                    <td><label>Tên:</label><br>
                                    <input type="text" name="contact_button_default_contacts[<?php echo intval($index); ?>][name]" 
                                           value="<?php echo esc_attr(isset($contact['name']) ? $contact['name'] : ''); ?>" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <td><label>Số điện thoại:</label><br>
                                    <input type="text" name="contact_button_default_contacts[<?php echo intval($index); ?>][phone]" 
                                           value="<?php echo esc_attr(isset($contact['phone']) ? $contact['phone'] : ''); ?>" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <td><label>Zalo:</label><br>
                                    <input type="text" name="contact_button_default_contacts[<?php echo intval($index); ?>][zalo]" 
                                           value="<?php echo esc_attr(isset($contact['zalo']) ? $contact['zalo'] : ''); ?>" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <td><label>Chuyên môn/Mô tả:</label><br>
                                    <textarea name="contact_button_default_contacts[<?php echo intval($index); ?>][description]" 
                                             class="regular-text" style="height: 60px;" placeholder="VD: Tư vấn tổng quát, hỗ trợ khách hàng..."><?php echo esc_textarea(isset($contact['description']) ? $contact['description'] : ''); ?></textarea></td>
                                </tr>
                                <tr>
                                    <td><button type="button" class="button remove-contact">Xóa</button></td>
                                </tr>
                            </table>
                            <hr>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <button type="button" id="add-contact" class="button button-secondary">+ Thêm Tư Vấn Viên</button>
                
                <?php submit_button(); ?>
            </form>
            
            <?php if (class_exists('WooCommerce')): ?>
            <div class="notice notice-success">
                <p><strong>WooCommerce được phát hiện!</strong> Bạn có thể cài đặt tư vấn viên riêng cho từng sản phẩm trong trang chỉnh sửa sản phẩm, tab "Tư Vấn Viên".</p>
            </div>
            <?php else: ?>
            <div class="notice notice-info">
                <p><strong>Thông báo:</strong> Cài đặt WooCommerce để có thêm tùy chọn cài đặt tư vấn viên riêng cho từng sản phẩm.</p>
            </div>
            <?php endif; ?>
        </div>
        
        <style>
        .contact-item {
            border: 1px solid #ddd;
            padding: 15px;
            margin: 10px 0;
            background: #f9f9f9;
            border-radius: 5px;
        }
        .contact-item h4 {
            margin-top: 0;
            color: #0073aa;
        }
        .remove-contact {
            background: #dc3232 !important;
            color: white !important;
            border: none !important;
        }
        #add-contact {
            margin: 20px 0;
            background: #0073aa !important;
            color: white !important;
            border: none !important;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            var contactIndex = <?php echo count($contacts); ?>;
            
            $('#add-contact').click(function() {
                var html = '<div class="contact-item" data-index="' + contactIndex + '">' +
                    '<h4>Tư vấn viên #' + (contactIndex + 1) + '</h4>' +
                    '<table class="form-table">' +
                    '<tr><td><label>Tên:</label><br><input type="text" name="contact_button_default_contacts[' + contactIndex + '][name]" value="" class="regular-text" /></td></tr>' +
                    '<tr><td><label>Số điện thoại:</label><br><input type="text" name="contact_button_default_contacts[' + contactIndex + '][phone]" value="" class="regular-text" /></td></tr>' +
                    '<tr><td><label>Zalo:</label><br><input type="text" name="contact_button_default_contacts[' + contactIndex + '][zalo]" value="" class="regular-text" /></td></tr>' +
                    '<tr><td><label>Chuyên môn/Mô tả:</label><br><textarea name="contact_button_default_contacts[' + contactIndex + '][description]" class="regular-text" style="height: 60px;" placeholder="VD: Tư vấn tổng quát, hỗ trợ khách hàng..."></textarea></td></tr>' +
                    '<tr><td><button type="button" class="button remove-contact">Xóa</button></td></tr>' +
                    '</table><hr></div>';
                
                $('#contact-list').append(html);
                contactIndex++;
            });
            
            $(document).on('click', '.remove-contact', function() {
                $(this).closest('.contact-item').remove();
            });
        });
        </script>
        <?php
    }
    
    // Add meta boxes for posts/pages (giữ nguyên cho trang/bài viết thường)
    public function add_meta_boxes() {
        $screens = array('post', 'page');
        foreach ($screens as $screen) {
            add_meta_box(
                'contact-button-meta',
                'Cài Đặt Liên Hệ Trang Này',
                array($this, 'meta_box_callback'),
                $screen,
                'side'
            );
        }
    }
    
    public function meta_box_callback($post) {
        if (!$post) {
            return;
        }
        
        wp_nonce_field('contact_button_meta_nonce', 'contact_button_meta_nonce');
        
        $page_contacts = get_post_meta($post->ID, '_contact_button_contacts', true);
        if (!is_array($page_contacts)) $page_contacts = array();
        $disable = get_post_meta($post->ID, '_contact_button_disable', true);
        
        echo '<div style="margin-bottom: 15px;">';
        echo '<label><input type="checkbox" name="contact_button_disable" value="1" ' . checked(1, $disable, false) . '> Tắt nút liên hệ cho trang này</label>';
        echo '</div>';
        
        echo '<h4>Tư vấn viên cho trang này:</h4>';
        echo '<div id="page-contact-list">';
        
        if (!empty($page_contacts)) {
            foreach ($page_contacts as $index => $contact) {
                echo '<div class="page-contact-item" data-index="' . intval($index) . '" style="border: 1px solid #ddd; padding: 10px; margin: 5px 0; background: #f9f9f9;">';
                echo '<strong>Tư vấn viên #' . intval($index + 1) . '</strong><br>';
                echo '<label>Tên:</label><br><input type="text" name="page_contacts[' . intval($index) . '][name]" value="' . esc_attr(isset($contact['name']) ? $contact['name'] : '') . '" style="width: 100%; margin-bottom: 5px;" /><br>';
                echo '<label>SĐT:</label><br><input type="text" name="page_contacts[' . intval($index) . '][phone]" value="' . esc_attr(isset($contact['phone']) ? $contact['phone'] : '') . '" style="width: 100%; margin-bottom: 5px;" /><br>';
                echo '<label>Zalo:</label><br><input type="text" name="page_contacts[' . intval($index) . '][zalo]" value="' . esc_attr(isset($contact['zalo']) ? $contact['zalo'] : '') . '" style="width: 100%; margin-bottom: 5px;" /><br>';
                echo '<label>Mô tả:</label><br><textarea name="page_contacts[' . intval($index) . '][description]" style="width: 100%; height: 50px; margin-bottom: 5px;">' . esc_textarea(isset($contact['description']) ? $contact['description'] : '') . '</textarea><br>';
                echo '<button type="button" class="button remove-page-contact" style="background: #dc3232; color: white;">Xóa</button>';
                echo '</div>';
            }
        }
        
        echo '</div>';
        echo '<button type="button" id="add-page-contact" class="button" style="background: #0073aa; color: white; margin-top: 10px;">+ Thêm Tư Vấn Viên</button>';
        
        echo '<script>
        jQuery(document).ready(function($) {
            var pageContactIndex = ' . count($page_contacts) . ';
            
            $("#add-page-contact").click(function() {
                var html = "<div class=\"page-contact-item\" data-index=\"" + pageContactIndex + "\" style=\"border: 1px solid #ddd; padding: 10px; margin: 5px 0; background: #f9f9f9;\">" +
                    "<strong>Tư vấn viên #" + (pageContactIndex + 1) + "</strong><br>" +
                    "<label>Tên:</label><br><input type=\"text\" name=\"page_contacts[" + pageContactIndex + "][name]\" value=\"\" style=\"width: 100%; margin-bottom: 5px;\" /><br>" +
                    "<label>SĐT:</label><br><input type=\"text\" name=\"page_contacts[" + pageContactIndex + "][phone]\" value=\"\" style=\"width: 100%; margin-bottom: 5px;\" /><br>" +
                    "<label>Zalo:</label><br><input type=\"text\" name=\"page_contacts[" + pageContactIndex + "][zalo]\" value=\"\" style=\"width: 100%; margin-bottom: 5px;\" /><br>" +
                    "<label>Mô tả:</label><br><textarea name=\"page_contacts[" + pageContactIndex + "][description]\" style=\"width: 100%; height: 50px; margin-bottom: 5px;\"></textarea><br>" +
                    "<button type=\"button\" class=\"button remove-page-contact\" style=\"background: #dc3232; color: white;\">Xóa</button>" +
                    "</div>";
                
                $("#page-contact-list").append(html);
                pageContactIndex++;
            });
            
            $(document).on("click", ".remove-page-contact", function() {
                $(this).closest(".page-contact-item").remove();
            });
        });
        </script>';
    }
    
    public function save_meta_boxes($post_id) {
        if (!isset($_POST['contact_button_meta_nonce']) || !wp_verify_nonce($_POST['contact_button_meta_nonce'], 'contact_button_meta_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save disable setting
        $disable = isset($_POST['contact_button_disable']) ? 1 : 0;
        update_post_meta($post_id, '_contact_button_disable', $disable);
        
        // Save page contacts
        $contacts = array();
        if (isset($_POST['page_contacts']) && is_array($_POST['page_contacts'])) {
            foreach ($_POST['page_contacts'] as $contact) {
                if (is_array($contact) && (!empty($contact['name']) || !empty($contact['phone']) || !empty($contact['zalo']))) {
                    $contacts[] = array(
                        'name' => sanitize_text_field(isset($contact['name']) ? $contact['name'] : ''),
                        'phone' => sanitize_text_field(isset($contact['phone']) ? $contact['phone'] : ''),
                        'zalo' => sanitize_text_field(isset($contact['zalo']) ? $contact['zalo'] : ''),
                        'description' => sanitize_textarea_field(isset($contact['description']) ? $contact['description'] : '')
                    );
                }
            }
        }
        update_post_meta($post_id, '_contact_button_contacts', $contacts);
    }
    
    public function display_contact_button() {
        // Check if plugin is enabled
        if (!get_option('contact_button_enable')) {
            return;
        }
        
        // Check if disabled for current page/product
        if (is_singular()) {
            $post_id = get_the_ID();
            if (!$post_id) {
                return;
            }
            
            // Check for product-specific disable setting (WooCommerce)
            if ($this->is_wc_product() && get_post_meta($post_id, '_disable_contact_for_product', true)) {
                return;
            }
            
            // Check for general page disable setting
            if (get_post_meta($post_id, '_contact_button_disable', true)) {
                return;
            }
        }
        
        // Get contacts based on current page type
        $contacts = array();
        
        if (is_singular()) {
            $post_id = get_the_ID();
            
            // For WooCommerce products, check product-specific contacts first
            if ($this->is_wc_product() && class_exists('WooCommerce')) {
                $product_contacts = get_post_meta($post_id, '_product_contact_consultants', true);
                if (!empty($product_contacts) && is_array($product_contacts)) {
                    $contacts = $product_contacts;
                }
            }
            
            // If no product contacts, check page-specific contacts
            if (empty($contacts)) {
                $page_contacts = get_post_meta($post_id, '_contact_button_contacts', true);
                if (!empty($page_contacts) && is_array($page_contacts)) {
                    $contacts = $page_contacts;
                }
            }
        }
        
        // Use default if no page/product-specific contacts
        if (empty($contacts)) {
            $contacts = get_option('contact_button_default_contacts', array());
            if (!is_array($contacts)) {
                $contacts = array();
            }
        }
        
        // Don't show if no contacts
        if (empty($contacts)) {
            return;
        }
        
        // Filter out empty contacts
        $valid_contacts = array();
        foreach ($contacts as $contact) {
            if (is_array($contact) && (!empty($contact['phone']) || !empty($contact['zalo']))) {
                $valid_contacts[] = $contact;
            }
        }
        
        if (empty($valid_contacts)) {
            return;
        }
        
        $zalo_icon_url = $this->get_zalo_icon_url();
        
        ?>
        <div id="contact-button-widget">
            <div class="contact-main-btn">
                <div class="contact-icon-container">
                    <!-- Menu Icon -->
                    <div class="contact-icon menu-icon active">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 6h18v2H3V6zm0 5h18v2H3v-2zm0 5h18v2H3v-2z"/>
                        </svg>
                    </div>
                    
                    <!-- Phone Icon -->
                    <div class="contact-icon phone-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M6.62 10.79a15.05 15.05 0 006.59 6.59l2.2-2.2a1 1 0 011.01-.24c1.11.37 2.31.57 3.58.57a1 1 0 011 1v3.5a1 1 0 01-1 1C12.08 22.82 1.18 11.92 1 3a1 1 0 011-1h3.5a1 1 0 011 1c0 1.27.2 2.47.57 3.58a1 1 0 01-.24 1.01l-2.2 2.2z"/>
                        </svg>
                    </div>
                    
                    <!-- Zalo Icon -->
                    <div class="contact-icon zalo-icon">
                        <?php if ($zalo_icon_url): ?>
                        <img src="<?php echo esc_url($zalo_icon_url); ?>" alt="Zalo" style="width:24px;height:24px;">
                        <?php else: ?>
                        <svg viewBox="0 0 24 24">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="contact-options">
                <div class="contact-options-content">
                    <?php foreach ($valid_contacts as $index => $contact): ?>
                        <?php if (!empty($contact['name'])): ?>
                            <div class="contact-person-header">
                                <div class="contact-person-avatar">
                                    <?php echo strtoupper(substr($contact['name'], 0, 1)); ?>
                                </div>
                                <div class="contact-person-info">
                                    <span class="contact-person-name"><?php echo esc_html($contact['name']); ?></span>
                                    <?php if (!empty($contact['description'])): ?>
                                        <span class="contact-person-desc"><?php echo esc_html($contact['description']); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="contact-person-options">
                            <?php if (!empty($contact['phone'])): ?>
                            <a href="tel:<?php echo esc_attr($contact['phone']); ?>" class="contact-option phone-option">
                                <div class="contact-option-icon">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M6.62 10.79a15.05 15.05 0 006.59 6.59l2.2-2.2a1 1 0 011.01-.24c1.11.37 2.31.57 3.58.57a1 1 0 011 1v3.5a1 1 0 01-1 1C12.08 22.82 1.18 11.92 1 3a1 1 0 011-1h3.5a1 1 0 011 1c0 1.27.2 2.47.57 3.58a1 1 0 01-.24 1.01l-2.2 2.2z"/>
                                    </svg>
                                </div>
                                <div class="contact-option-content">
                                    <div class="contact-option-title">Gọi điện</div>
                                    <div class="contact-option-subtitle"><?php echo esc_html($contact['phone']); ?></div>
                                </div>
                            </a>
                            <?php endif; ?>
                            
                            <?php if (!empty($contact['zalo'])): ?>
                            <a href="https://zalo.me/<?php echo esc_attr($contact['zalo']); ?>" 
                            class="contact-option zalo-option" target="_blank" rel="noopener">
                                <div class="contact-option-icon zalo-icon">
                                    <?php if ($zalo_icon_url): ?>
                                    <img src="<?php echo esc_url($zalo_icon_url); ?>" alt="Zalo" style="width:24px;height:24px;">
                                    <?php else: ?>
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                    </svg>
                                    <?php endif; ?>
                                </div>
                                <div class="contact-option-content">
                                    <div class="contact-option-title">Chat Zalo</div>
                                    <div class="contact-option-subtitle">
                                        <?php echo esc_html(!empty($contact['name']) ? $contact['name'] : $contact['zalo']); ?>
                                    </div>
                                </div>
                            </a>
                        <?php endif; ?>
                        </div>
                        
                        <?php if ($index < count($valid_contacts) - 1): ?>
                            <div class="contact-separator"></div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <style>
        #contact-button-widget {
            position: fixed;
            right: 20px;
            bottom: 13%;
            transform: translateY(-50%);
            z-index: 9999;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .contact-main-btn {
            background: linear-gradient(135deg, #0084FF 0%, #0066CC 100%);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 8px 25px rgba(0, 132, 255, 0.4);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            user-select: none;
            position: relative;
            overflow: hidden;
        }
        
        .contact-main-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }
        
        .contact-main-btn:hover::before {
            left: 100%;
        }
        
        .contact-main-btn:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 12px 35px rgba(0, 132, 255, 0.5);
        }
        
        .contact-main-btn.active {
            transform: scale(0.95);
            box-shadow: 0 4px 15px rgba(0, 132, 255, 0.6);
        }
        
        .contact-icon-container {
            position: relative;
            width: 28px;
            height: 28px;
        }
        
        .contact-icon {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transform: scale(0.5) rotateY(90deg);
            transition: all 0.6s ease;
        }
        
        .contact-icon.active {
            opacity: 1;
            transform: scale(1) rotateY(0deg);
        }
        
        .contact-icon svg {
            width: 100%;
            height: 100%;
            fill: white;
        }
        
        /* Animation cho các icon khi chưa click */
        .contact-main-btn:not(.clicked) .contact-icon {
            animation: iconRotate 4s infinite;
        }
        
        .contact-main-btn:not(.clicked) .menu-icon {
            animation-delay: 0s;
        }
        
        .contact-main-btn:not(.clicked) .phone-icon {
            animation-delay: 1.33s;
        }
        
        .contact-main-btn:not(.clicked) .zalo-icon {
            animation-delay: 2.66s;
        }
        
        @keyframes iconRotate {
            0%, 25% { 
                opacity: 1; 
                transform: scale(1) rotateY(0deg) rotateZ(0deg);
            }
            28%, 95% { 
                opacity: 0; 
                transform: scale(0.3) rotateY(180deg) rotateZ(360deg);
            }
            98%, 100% { 
                opacity: 1; 
                transform: scale(1) rotateY(0deg) rotateZ(0deg);
            }
        }
        
        .contact-options {
            position: absolute;
            bottom: 70px;
            right: 0;
            background: white;
            border-radius: 16px;
            min-width: 320px;
            max-width: 350px;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
            opacity: 0;
            visibility: hidden;
            transform: translateY(20px) scale(0.95);
            transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            border: 1px solid rgba(0, 0, 0, 0.08);
            /* Responsive height handling */
            max-height: 70vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .contact-options.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0) scale(1);
        }
        
        .contact-options-content {
            overflow-y: auto;
            flex: 1;
            /* Custom scrollbar */
            scrollbar-width: thin;
            scrollbar-color: rgba(0, 132, 255, 0.3) transparent;
        }
        
        .contact-options-content::-webkit-scrollbar {
            width: 6px;
        }
        
        .contact-options-content::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .contact-options-content::-webkit-scrollbar-thumb {
            background: rgba(0, 132, 255, 0.3);
            border-radius: 3px;
        }
        
        .contact-options-content::-webkit-scrollbar-thumb:hover {
            background: rgba(0, 132, 255, 0.5);
        }
        
        .contact-person-header {
            display: flex;
            align-items: center;
            padding: 16px 20px 12px;
            gap: 12px;
            color: #333;
        }
        
        .contact-person-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 16px;
            text-transform: uppercase;
            flex-shrink: 0;
        }
        
        .contact-person-info {
            display: flex;
            flex-direction: column;
            flex: 1;
            min-width: 0;
        }
        
        .contact-person-name {
            font-weight: 600;
            font-size: 15px;
            color: #333;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .contact-person-desc {
            font-size: 12px;
            color: #666;
            margin-top: 2px;
            line-height: 1.3;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .contact-person-options {
            padding: 0 20px;
        }
        
        .contact-option {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 12px;
            text-decoration: none;
            color: #333;
            transition: all 0.2s ease;
            border: 1px solid transparent;
            position: relative;
            overflow: hidden;
        }
        
        .contact-option::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            transition: left 0.3s ease;
            z-index: 0;
        }
        
        .contact-option > * {
            position: relative;
            z-index: 1;
        }
        
        .phone-option {
            border-color: rgba(37, 211, 102, 0.2);
            background: rgba(37, 211, 102, 0.05);
        }
        
        .phone-option::before {
            background: linear-gradient(135deg, #25D366, #128C7E);
        }
        
        .phone-option:hover::before {
            left: 0;
        }
        
        .zalo-option {
            border-color: rgba(0, 132, 255, 0.2);
            background: rgba(0, 132, 255, 0.05);
        }
        
        .zalo-option::before {
            background: linear-gradient(135deg, #0084FF, #0066CC);
        }
        
        .zalo-option:hover::before {
            left: 0;
        }
        
        .contact-option:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            color: white;
            text-decoration: none;
        }
        
        .contact-option:hover .contact-option-icon svg {
            fill: white;
        }
        
        .contact-option:hover .contact-option-content {
            color: white;
        }
        
        .contact-option-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .phone-option .contact-option-icon {
            background: rgba(37, 211, 102, 0.1);
        }
        
        .zalo-option .contact-option-icon {
            background: rgba(0, 132, 255, 0.1);
        }
        
        .contact-option-icon svg {
            width: 20px;
            height: 20px;
            transition: fill 0.2s ease;
        }
        
        .phone-option .contact-option-icon svg {
            fill: #25D366;
        }
        
        .zalo-option .contact-option-icon svg {
            fill: #0084FF;
        }
        
        .contact-option-content {
            flex: 1;
            transition: color 0.2s ease;
            min-width: 0;
        }
        
        .contact-option-title {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .contact-option-subtitle {
            font-size: 12px;
            opacity: 0.8;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .contact-separator {
            height: 1px;
            background: linear-gradient(to right, transparent, #e0e0e0, transparent);
            margin: 16px 20px;
        }
        
        /* Animation pulse cho nút chính */
        @keyframes pulse {
            0% { 
                box-shadow: 0 8px 25px rgba(0, 132, 255, 0.4), 
                           0 0 0 0 rgba(0, 132, 255, 0.7);
            }
            50% { 
                box-shadow: 0 8px 25px rgba(0, 132, 255, 0.6), 
                           0 0 0 10px rgba(0, 132, 255, 0);
            }
            100% { 
                box-shadow: 0 8px 25px rgba(0, 132, 255, 0.4), 
                           0 0 0 0 rgba(0, 132, 255, 0);
            }
        }
        
        .contact-main-btn:not(.clicked) {
            animation: pulse 3s infinite;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            #contact-button-widget {
                bottom: 20px;
                right: 15px;
                transform: none;
            }
            
            .contact-main-btn {
                width: 55px;
                height: 55px;
            }
            
            .contact-icon-container {
                width: 24px;
                height: 24px;
            }
            
            .contact-options {
                min-width: 280px;
                max-width: calc(100vw - 40px);
                right: -10px;
                max-height: 60vh;
            }
            
            .contact-person-header {
                padding: 14px 16px 10px;
            }
            
            .contact-person-avatar {
                width: 36px;
                height: 36px;
                font-size: 14px;
            }
            
            .contact-person-name {
                font-size: 14px;
            }
            
            .contact-person-desc {
                font-size: 11px;
            }
            
            .contact-person-options {
                padding: 0 16px;
            }
            
            .contact-option {
                padding: 10px;
                gap: 10px;
            }
            
            .contact-option-icon {
                width: 36px;
                height: 36px;
            }
            
            .contact-option-title {
                font-size: 13px;
            }
            
            .contact-option-subtitle {
                font-size: 11px;
            }
            
            .contact-separator {
                margin: 12px 16px;
            }
        }
        
        /* Màn hình nhỏ hơn */
        @media (max-width: 480px) {
            .contact-options {
                min-width: 260px;
                max-width: calc(100vw - 30px);
                right: -5px;
                max-height: 55vh;
            }
            
            .contact-person-header {
                padding: 12px 14px 8px;
            }
            
            .contact-person-avatar {
                width: 32px;
                height: 32px;
                font-size: 13px;
            }
            
            .contact-person-options {
                padding: 0 14px;
            }
            
            .contact-option {
                padding: 8px;
            }
        }
        
        /* Màn hình cao độ thấp */
        @media (max-height: 600px) {
            #contact-button-widget {
                bottom: 10px;
                right: 15px;
            }
            
            .contact-options {
                max-height: 50vh;
                bottom: 65px;
            }
        }
        
        /* Tablet */
        @media (min-width: 769px) and (max-width: 1024px) {
            .contact-options {
                max-height: 65vh;
            }
        }
        
        /* Ensure smooth scrolling */
        .contact-options-content {
            -webkit-overflow-scrolling: touch;
            scroll-behavior: smooth;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            var isOpen = false;
            
            $('.contact-main-btn').click(function(e) {
                e.preventDefault();
                var options = $('.contact-options');
                var btn = $(this);
                
                if (isOpen) {
                    options.removeClass('show');
                    btn.removeClass('clicked');
                    isOpen = false;
                } else {
                    options.addClass('show');
                    btn.addClass('clicked');
                    isOpen = true;
                    
                    // Auto-adjust position on small screens
                    var windowHeight = $(window).height();
                    var optionsHeight = options.outerHeight();
                    var btnOffset = btn.offset();
                    
                    // If options would go above viewport, adjust position
                    if (btnOffset.top - optionsHeight - 10 < 0) {
                        options.css({
                            'bottom': 'auto',
                            'top': '70px'
                        });
                    } else {
                        options.css({
                            'bottom': '70px',
                            'top': 'auto'
                        });
                    }
                }
            });
            
            // Close when clicking outside
            $(document).click(function(e) {
                if (!$(e.target).closest('#contact-button-widget').length && isOpen) {
                    $('.contact-options').removeClass('show');
                    $('.contact-main-btn').removeClass('clicked');
                    isOpen = false;
                }
            });
            
            // Prevent closing when clicking inside options
            $('.contact-options').click(function(e) {
                e.stopPropagation();
            });
            
            // Handle window resize
            $(window).resize(function() {
                if (isOpen) {
                    var options = $('.contact-options');
                    var btn = $('.contact-main-btn');
                    var windowHeight = $(window).height();
                    var optionsHeight = options.outerHeight();
                    var btnOffset = btn.offset();
                    
                    // Reset position styles
                    options.css({
                        'bottom': '70px',
                        'top': 'auto'
                    });
                    
                    // Re-calculate if needed
                    setTimeout(function() {
                        if (btnOffset.top - optionsHeight - 10 < 0) {
                            options.css({
                                'bottom': 'auto',
                                'top': '70px'
                            });
                        }
                    }, 100);
                }
            });
        });
        </script>
        <?php
    }
    
    // Helper method to check if current page is a WooCommerce product
    private function is_wc_product() {
        return function_exists('is_product') && is_product();
    }
    
    // Helper method to get Zalo icon URL
    private function get_zalo_icon_url() {
        $zalo_icon_path = plugin_dir_path(__FILE__) . 'Icon_of_Zalo.svg.png';
        if (file_exists($zalo_icon_path)) {
            return plugin_dir_url(__FILE__) . 'Icon_of_Zalo.svg.png';
        }
        return false;
    }
    
    // Save contact list via AJAX
    public function save_contact_list() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'contact_nonce')) {
            wp_die('Security check failed');
        }
        
        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        // Process and save data
        $contacts = array();
        if (isset($_POST['contacts']) && is_array($_POST['contacts'])) {
            foreach ($_POST['contacts'] as $contact) {
                if (is_array($contact) && (!empty($contact['name']) || !empty($contact['phone']) || !empty($contact['zalo']))) {
                    $contacts[] = array(
                        'name' => sanitize_text_field(isset($contact['name']) ? $contact['name'] : ''),
                        'phone' => sanitize_text_field(isset($contact['phone']) ? $contact['phone'] : ''),
                        'zalo' => sanitize_text_field(isset($contact['zalo']) ? $contact['zalo'] : ''),
                        'description' => sanitize_textarea_field(isset($contact['description']) ? $contact['description'] : '')
                    );
                }
            }
        }
        
        update_option('contact_button_default_contacts', $contacts);
        
        wp_send_json_success('Contacts saved successfully');
    }
}

// Initialize the plugin
new ContactButtonPlugin();

// Activation hook
register_activation_hook(__FILE__, 'contact_button_activate');
function contact_button_activate() {
    add_option('contact_button_enable', 1);
    // Add default contact if none exists
    $default_contacts = array(
        array(
            'name' => 'Minh Tâm Tư Vấn',
            'phone' => '0767627382',
            'zalo' => '0767627382',
            'description' => 'Tư vấn tổng quát, hỗ trợ khách hàng'
        )
    );
    
    // Only add default if no existing contacts
    $existing_contacts = get_option('contact_button_default_contacts', array());
    if (empty($existing_contacts)) {
        update_option('contact_button_default_contacts', $default_contacts);
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'contact_button_deactivate');
function contact_button_deactivate() {
    // Clean up if needed - but keep data for reactivation
}
?>